package com.Bank;

/**
 * @ author Monika Szucs and Henry
 */

public class BankAccount {
    double balanceCDN;
    final String accountNumber;
    final String memberLastName;

    // constructor
    BankAccount(double balanceCDN, final String accountNumber, final String memberLastName)
    {
        this.balanceCDN = balanceCDN;
        this.accountNumber = accountNumber;
        this.memberLastName = memberLastName;
    }

    public void withdraw(double withdrawAmount)
    {
        balanceCDN -= withdrawAmount;
    }

    public void deposit(double depositAmount)
    {
        balanceCDN += depositAmount;
    }

    public void transfer(double amountCDN, BankAccount recipientAccount)
    {
        balanceCDN -= amountCDN;
        recipientAccount.deposit(amountCDN);
        withdraw(amountCDN);
        deposit(amountCDN);
    }
}
