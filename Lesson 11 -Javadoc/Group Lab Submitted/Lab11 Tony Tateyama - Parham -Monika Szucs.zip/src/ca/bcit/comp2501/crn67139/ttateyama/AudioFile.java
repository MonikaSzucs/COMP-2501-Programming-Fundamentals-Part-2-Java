/*
 * AudioFile.java
 * COMP 2501 - CRN: 67139
 * Wednesday evenings, Spring/Summer 2022
 * Lab #11
 */
package ca.bcit.comp2501.crn67139.ttateyama;

/**
 * Audio file subclass to the music media superclass.
 *
 * @author Tony Tateyama
 * @author Parham
 * @author Monika Szucs
 */
public class AudioFile extends MusicMedia {
    private final String fileType;

    /*
     * Constant to define all allowed audio file types
     */
    private final static String[] VALID_FILE_TYPES = {"mp3", "m4a", "wav"};

    /**
     * Audio file object constructor that extends the MusicMedia superclass by
     * adding an audio file type property.
     *
     * @param artist            The name of the music artist
     * @param title             The music media title
     * @param trackCount        The number of song tracks
     * @param totalMinutes      The total running time
     * @param yearPublished     The year of publication
     * @param fileType          The audio file type
     */
    public AudioFile(final String artist,
                     final String title,
                     final int trackCount,
                     final int totalMinutes,
                     final int yearPublished,
                     final String fileType) {
        super(artist, title, trackCount, totalMinutes, yearPublished);

        if (isValidFileType(fileType)) {
            this.fileType = fileType;
        } else {
            throw new IllegalArgumentException("invalid file type: " +
                                               fileType);
        }
    }

    /*
     * Check the audio file type
     */
    private boolean isValidFileType(final String fileType) {
        for (String validFileType : VALID_FILE_TYPES)
            if (fileType.equalsIgnoreCase(validFileType)) return true;

        return false;
    }

    /**
     * Audio file type getter
     *
     * @return      File type
     */
    public String getFileType() {
        return fileType;
    }

    /**
     * Simulate playing an audio file selection, and display all its properties
     */
    public void playSelection() {
        super.playSelection();
        System.out.println("You selected the Audio File " +
            getTitle() + " by " + getArtist() + ".");
        System.out.println("This file is in " + getFileType() + " format, " +
            "from the year " + getYearPublished() + ".");
    }

    /**
     * Concatenation of all audio file object properties
     *
     * @return      String with all audio file property values
     */
    @Override
    public String toString() {
        return "AudioFile [" +
            "fileType=" + fileType +
            ", " + super.toString();
    }
}
