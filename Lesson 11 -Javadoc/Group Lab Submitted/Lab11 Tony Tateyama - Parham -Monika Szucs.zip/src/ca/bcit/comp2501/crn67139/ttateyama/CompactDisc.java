/*
 * CompactDisc.java
 * COMP 2501 - CRN: 67139
 * Wednesday evenings, Spring/Summer 2022
 * Lab #11
 */
package ca.bcit.comp2501.crn67139.ttateyama;

/**
 * Compact disc subclass to the music media superclass.
 *
 * @author Tony Tateyama
 * @author Parham
 * @author Monika Szucs
 */
public class CompactDisc extends MusicMedia {
    private final boolean bonusTracks;
    private final boolean digipak;

    /**
     * Compact disc object constructor that extends the MusicMedia superclass
     * by adding properties to indicate whether bonus tracks are included and
     * if the CD packaging is a digipak.
     *
     * @param artist            The name of the music artist
     * @param title             The music media title
     * @param trackCount        The number of song tracks
     * @param totalMinutes      The total running time
     * @param yearPublished     The year of publication
     * @param bonusTracks       Whether the CD includes bonus tracks
     * @param digipak           Whether the CD packaging is a digipak
     */
    public CompactDisc(final String artist,
                       final String title,
                       final int trackCount,
                       final int totalMinutes,
                       final int yearPublished,
                       final boolean bonusTracks,
                       final boolean digipak) {
        super(artist, title, trackCount, totalMinutes, yearPublished);
        this.bonusTracks = bonusTracks;
        this.digipak = digipak;
    }

    /**
     * Inclusion of CD bonus track getter
     *
     * @return      Bonus track inclusion
     */
    public boolean hasBonusTracks() {
        return bonusTracks;
    }

    /**
     * Digipak CD packaging getter
     *
     * @return      Digipak packaging
     */
    public boolean isDigipak() {
        return digipak;
    }

    /**
     * Simulate playing a CD selection, and display all its properties
     */
    public void playSelection() {
        super.playSelection();
        System.out.println("You selected the CD " +
            getTitle() + " by " + getArtist() + ".");
        System.out.println("This is a Compact Disc " +
            "from the year " + getYearPublished() + ".");
    }

    /**
     * Concatenation of all CD object properties
     *
     * @return      String with all CD property values
     */
    @Override
    public String toString() {
        return "CompactDisc [" +
            "bonusTracks=" + bonusTracks +
            ", digipak=" + digipak +
            ", " + super.toString();
    }
}
