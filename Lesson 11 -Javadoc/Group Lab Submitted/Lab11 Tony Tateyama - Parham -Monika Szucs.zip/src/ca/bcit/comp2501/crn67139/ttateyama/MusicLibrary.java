/*
 * MusicLibrary.java
 * COMP 2501 - CRN: 67139
 * Wednesday evenings, Spring/Summer 2022
 * Lab #11
 */
package ca.bcit.comp2501.crn67139.ttateyama;

import java.util.ArrayList;
import java.util.List;

/**
 * A music library class for the music media collection.  Provides methods to
 * add media selections, display collection items, and simulation of title
 * playback.
 *
 * @author Tony Tateyama
 * @author Parham
 * @author Monika Szucs
 */
public class MusicLibrary {
    private final List<MusicMedia> musicLibrary;

    /**
     * Music library constructor for the library collection
     */
    MusicLibrary() {
        musicLibrary = new ArrayList<>();
    }

    /**
     * Add a music media item to the collection
     *
     * @param media     Media item to add
     */
    public void addMedia(final MusicMedia media){
        if (media != null) {
            musicLibrary.add(media);
        } else {
            throw new NullPointerException("null music media");
        }
    }

    /**
     * Display properties of all items in the media library collection
     */
    public void displayLibrary() {
        for (MusicMedia media : musicLibrary) {
            System.out.println(media.toString());
        }
    }

    /**
     * Simulate playing a title in the collection
     *
     * @param title     The title to lookup and "play"
     */
    public void playTitle(final String title) {
        if (title != null && !title.isBlank())
            for (MusicMedia media : musicLibrary)
                if (title.equalsIgnoreCase(media.getTitle().toLowerCase()))
                    media.playSelection();
    }
}
