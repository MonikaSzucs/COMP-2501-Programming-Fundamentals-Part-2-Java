/*
 * MusicMedia.java
 * COMP 2501 - CRN: 67139
 * Wednesday evenings, Spring/Summer 2022
 * Lab #11
 */
package ca.bcit.comp2501.crn67139.ttateyama;

/**
 * A music media superclass used to build a music library consisting of
 * vinyl record, compact disc and digital audio file media format subclasses
 *
 * @author Tony Tateyama
 * @author Parham
 * @author Monika Szucs
 */
public class MusicMedia {
    private final String artist;
    private final String title;
    private final int    trackCount;
    private final int    totalMinutes;
    private final int    yearPublished;

    /*
     * Constants for checking the number of music tracks.  The world record is
     * 446 tracks on a digital album.
     */
    private final static int MIN_TRACKS = 1;
    private final static int MAX_TRACKS = 450;

    /*
     * Constants for checking the total music runtime.  The world record for
     * the longest song is 48:39:35 (hh:mm:ss)
     */
    private final static int MIN_RUNTIME = 1;
    private final static int MAX_RUNTIME = 2920;

    /*
     * Constants for checking the recording's year of publication.
     */
    private final static int EARLIEST_RECORDING = 1860;
    private final static int CURRENT_YEAR = 2022;

    /**
     * The music media constructor
     *
     * @param artist            The name of the music artist
     * @param title             The music media title
     * @param trackCount        The number of song tracks
     * @param totalMinutes      The total running time
     * @param yearPublished     The year of publication
     */
    public MusicMedia(final String artist,
                      final String title,
                      final int    trackCount,
                      final int    totalMinutes,
                      final int    yearPublished) {
        if (isStringOkay(artist)) {
            this.artist = artist;
        } else {
            throw new IllegalArgumentException("invalid artist: " + artist);
        }

        if (isStringOkay(title)) {
            this.title = title;
        } else {
            throw new IllegalArgumentException("invalid title: " + title);
        }

        if (isValidTrackCount(trackCount)) {
            this.trackCount = trackCount;
        } else {
            throw new IllegalArgumentException("invalid track count: " +
                                               trackCount);
        }

        if (isValidRuntime(totalMinutes)) {
            this.totalMinutes = totalMinutes;
        } else {
            throw new IllegalArgumentException("invalid run time: " +
                                               totalMinutes);
        }

        if (isValidYear(yearPublished)) {
            this.yearPublished = yearPublished;
        } else {
            throw new IllegalArgumentException("invalid publication year: " +
                                               yearPublished);
        }
    }

    /*
     * Check for a null or blank string
     */
    private boolean isStringOkay(final String string) {
        return (string != null && !string.isBlank());
    }

    /*
     * Check for a valid track count number
     */
    private boolean isValidTrackCount(final int trackCount) {
        return (trackCount >= MIN_TRACKS && trackCount <= MAX_TRACKS);
    }

    /*
     * Check for a valid total run time
     */
    private boolean isValidRuntime(final int totalMinutes) {
        return (totalMinutes >= MIN_RUNTIME && totalMinutes <= MAX_RUNTIME);
    }

    /*
     * Check for a valid publication year
     */
    private boolean isValidYear(final int yearPublished) {
        return (yearPublished >= EARLIEST_RECORDING &&
                yearPublished <= CURRENT_YEAR);
    }

    /**
     * Music artist name getter
     *
     * @return      Artist
     */
    public String getArtist() {
        return artist;
    }

    /**
     * Music media title getter
     *
     * @return      Title
     */
    public String getTitle() {
        return title;
    }

    /**
     * Music media track number getter
     *
     * @return      Track count
     */
    public int getTrackCount() {
        return trackCount;
    }

    /**
     * Music media total running time getter
     *
     * @return      Total minutes
     */
    public double getTotalMinutes() {
        return totalMinutes;
    }

    /**
     * Music media publication year getter
     *
     * @return      Year published
     */
    public int getYearPublished() {
        return yearPublished;
    }

    /**
     * Display a selection from the library.  This message can be overridden
     * by media specific playSelection() methods.
     */
    public void playSelection() {
        System.out.println("Thank you for using our Music Library.");
    }

    /**
     * Concatenate music media object property values
     *
     * @return      String with all music media property values
     */
    @Override
    public String toString() {
        return "toString()=Album [" +
            "Artist=" + artist +
            ", title=" + title +
            ", trackCount=" + trackCount +
            ", totalMinutes=" + totalMinutes +
            "]]";
    }
}
