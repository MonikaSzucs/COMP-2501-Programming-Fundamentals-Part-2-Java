/*
 * MusicMediaLibrary.java
 * COMP 2501 - CRN: 67139
 * Wednesday evenings, Spring/Summer 2022
 * Lab #11
 */
package ca.bcit.comp2501.crn67139.ttateyama;

/**
 * A music library "driver" class to create the music media library
 * collection and populate it
 *
 * @author Tony Tateyama
 * @author Parham
 * @author Monika Szucs
 */
public class MusicMediaLibrary {
    private final MusicLibrary library;

    /**
     * The music media library constructor.  Adds music media to the collection
     */
    public MusicMediaLibrary() {
        library = new MusicLibrary();

        library.addMedia(new Record("The Beatles",
            "Hey Jude", 1, 7, 1968, 7, 45.0));
        library.addMedia(new CompactDisc("Neil Young & Crazy Horse",
            "Everybody Knows This Is Nowhere", 4, 40, 1969, false, false));
        library.addMedia(new AudioFile("Donnie Iris and The Cruisers",
            "Ah Leah!", 1, 4, 1980, "wav"));
        library.addMedia(new CompactDisc("Eagles",
            "Hotel California", 9, 43, 1976, false, false));
        library.addMedia(new CompactDisc("Kimbra",
            "Vows", 13, 50, 2012, true, true));
        library.addMedia(new CompactDisc("Tool",
            "10,000 Days", 11, 76, 2006, false, true));
    }

    /**
     * Instantiates the music media library, display the complete collection,
     * and simulate play back of a selection of titles.
     *
     * @param args      No command line parameters used
     */
    public static void main(final String[] args) {
        MusicMediaLibrary myMusic;

        myMusic = new MusicMediaLibrary();

        myMusic.library.displayLibrary();
        System.out.println();
        myMusic.library.playTitle("Hey Jude");
        System.out.println();
        myMusic.library.playTitle("Everybody Knows This Is Nowhere");
        System.out.println();
        myMusic.library.playTitle("Ah Leah!");
    }
}
