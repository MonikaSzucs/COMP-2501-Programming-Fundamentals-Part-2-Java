/*
 * Record.java
 * COMP 2501 - CRN: 67139
 * Wednesday evenings, Spring/Summer 2022
 * Lab #11
 */
package ca.bcit.comp2501.crn67139.ttateyama;

/**
 * Record subclass to the music media superclass.
 *
 * @author Tony Tateyama
 * @author Parham
 * @author Monika Szucs
 */
public class Record extends MusicMedia {
    private final int sizeInches;
    private final double rpm;

    private final static int[] VALID_SIZES = {7, 10, 12};
    private final static double[] VALID_RPM = {33.3, 45.0, 78.0};

    /**
     * Vinyl record constructor that extends the MusicMedia superclass by
     * adding disc size in inches and playback speed in rpm.
     *
     * @param artist            The name of the music artist
     * @param title             The music media title
     * @param trackCount        The number of song tracks
     * @param totalMinutes      The total running time
     * @param yearPublished     The year of publication
     * @param sizeInches        The record diameter in inches
     * @param rpm               The record playback speed in rpm
     */
    public Record(final String artist,
                  final String title,
                  final int trackCount,
                  final int totalMinutes,
                  final int yearPublished,
                  final int sizeInches,
                  final double rpm) {
        super(artist, title, trackCount, totalMinutes, yearPublished);

        if (isValidSize(sizeInches)) {
            this.sizeInches = sizeInches;
        } else {
            throw new IllegalArgumentException("invalid size: " + sizeInches);
        }

        if (isValidRpm(rpm)) {
            this.rpm = rpm;
        } else {
            throw new IllegalArgumentException("invalid rpm: " + rpm);
        }
    }

    /*
     * Check the record size
     */
    private boolean isValidSize(int sizeInches) {
        for (int validSize : VALID_SIZES)
            if (sizeInches == validSize) return true;

        return false;
    }

    /*
     * Check the record playback speed
     */
    private boolean isValidRpm(double rpm) {
        for (double validRpm : VALID_RPM)
            if (rpm == validRpm) return true;

        return false;
    }

    /**
     * Record diameter size getter
     *
     * @return      Size in inches
     */
    public int getSizeInches() {
        return sizeInches;
    }

    /**
     * Record playback speed getter
     *
     * @return      Speed in rpm
     */
    public double getRpm() {
        return rpm;
    }

    /**
     * Simulate playing a record selection, and display all its properties
     */
    public void playSelection() {
        super.playSelection();
        System.out.println("You selected the record " +
            getTitle() + " by " + getArtist() + ".");
        System.out.println("This is a " + getSizeInches() + " inch record " +
            "from " + getYearPublished() + ", playing at " +
            getRpm() + " rpm.");
    }

    /**
     * Concatenation of all record object properties
     *
     * @return      String with all record property values
     */
    @Override
    public String toString() {
        return "Record [" +
            "size=" + sizeInches +
            ", rpm=" + rpm +
            ", " + super.toString();
    }
}
