import javax.swing.text.AbstractDocument;
import java.util.Set;

public class Bank
{
    private String bankName;


    public Bank(final String bankName)
    {
        this.bankName = bankName;
    }

    public void setBankName(String bankName)
    {
        this.bankName = bankName;
    }

    public String getBankName()
    {
        return bankName;
    }

    public void addAccount(Object account)
    {
        System.out.println(account);

        Set<String> keys = account.keySet();
        for(String key: keys)
        {
            Student student = students.get(key);
            System.out.println("st #" + key + " is " +
                    student.getLastName() + " with gpa " +
                    student.getGpa());
        }
    }

    public void getAccount(String accountNumber)
    {

    }

    public void removeAccount(String accountNumber)
    {

    }

    //public void getNumberOfAccounts(BankAccount)
    {
        //return len(BankAccount);
    }

    public void getTotalAccountsBalance()
    {
        //totalCdn = balanceName;
        // for loop
    }

    //public void depositTo(amountCdn, accountNum)
    {
        //accounts[accountNum].deposit(amountCdn);
    }

    public void printAllCustomerData()
    {
        // for loop
    }

}
