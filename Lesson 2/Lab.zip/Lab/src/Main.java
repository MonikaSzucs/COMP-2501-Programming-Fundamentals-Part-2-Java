import java.util.HashMap;

public class Main {

    private static HashMap<String, BankAccount> bankAccounts;

    public static void main(final String[] args)
    {
        bankAccounts = new HashMap<>();
        Bank bank = new Bank("Bank of Kanada");

        BankAccount account1 = new BankAccount(100.0, "abc111", "woods");
        BankAccount account2 = new BankAccount(200.0, "def222", "gates");
        BankAccount account3 = new BankAccount(300.0, "ghi333", "bezos");
        BankAccount account4 = new BankAccount(400.0, "jkl444", "zuckerberg");

        bankAccounts.put("abc111", account1);
        bankAccounts.put("def222", account2);
        bankAccounts.put("ghi333", account3);
        bankAccounts.put("jkl444", account4);

        bank.addAccount(account1);
        //System.out.println("test");
        //System.out.println(bankAccounts);

        //bank.addAccount(account1);

    }
}
