package ca.bcit.comp2501.lab2b.monikaszucsandparhammehrgan;

/**
 * Main.java
 * COMP 2501 - CRN: 67139 - Wednesday Evenings, Spring/Summer 2022
 * Lab #2b
 *
 * @author Monika Szucs and Parham Mehrgan
 * @version 1.0
 */
public class Main
{
    public static void main(final String[] args)
    {
        Calendar event = new Calendar();
        event.printCalendar();
    }
}
