package ca.bcit.comp2501.lab2b.monikaszucsandparhammehrgan;

/**
 * @Authors Monika Szucs and Parham Mehrgan
 * @version 1.0
 */
public class Main
{
    public static void main(final String[] args)
    {
        Calendar event = new Calendar();
        event.printCalendar();
    }
}
