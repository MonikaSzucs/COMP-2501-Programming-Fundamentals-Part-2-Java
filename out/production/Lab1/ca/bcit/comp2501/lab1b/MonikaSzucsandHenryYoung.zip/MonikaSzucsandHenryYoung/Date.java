package ca.bcit.comp2501.lab1b.MonikaSzucsandHenryYoung;

/**
 * @ Authors Monika Szucs and Henry Young
 */

public class Date {
    // Properties for Date
    private String month;
    private int day;
    private int year;

    // Constructor for Date
    public Date(String month, int day, int year)
    {
        this.month = month;
        this.day = day;
        this.year = year;
    }

    // Setter for Month
    public void setMonth(String month)
    {
        this.month = month;
    }

    // Getter for Month
    public String getMonth()
    {
        if (month=="January" || month=="january")
        {
            return "1";
        } else if (month=="February" || month=="february")
        {
            return "2";
        } else if (month=="March" || month=="march")
        {
            return "3";
        } else if (month=="April" || month=="april")
        {
            return "4";
        } else if (month=="May" || month=="may")
        {
            return "5";
        } else if (month=="June" || month=="june")
        {
            return "6";
        } else if (month=="July" || month=="july")
        {
            return "7";
        } else if (month=="August" || month=="august")
        {
            return "8";
        } else if (month=="September" || month=="september")
        {
            return "9";
        } else if (month=="October" || month=="october")
        {
            return "10";
        } else if (month=="November" || month=="november")
        {
            return "11";
        } else if (month=="December" || month=="deceomber")
        {
            return "12";
        } else{
            return "0";
        }
    }

    // Setter for Day
    public void setDay(int day)
    {
        this.day = day;
    }

    //Getter for Day
    public int getDay()
    {
        return day;
    }

    // Setter for Year
    public void setYear(int year)
    {
        this.year = year;
    }

    // Getter for Year
    public int getYear()
    {
        return year;
    }

    // Getter for String containing Year, Month and Day
    public String getYyMmDd()
    {
        return getYear() + "-" + getMonth() + "-" + getDay();
    }
}
